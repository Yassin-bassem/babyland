Bubbles Kids Wear - Backup Archive
===================================
Generated: 2026-07-01T04:13:36.426Z

Restore: use the same Backup tab in the admin panel and upload either:
  - this .zip file (full restore)
  - a single tables/<table>.json file (restore only that table)

Folders:
 - tables/   <- authoritative data used for restore
 - by-version/  <- same rows split per version (read-only convenience)
 - global/   <- non-versioned tables

Row counts:
  versions: 1
  staff_members: 0
  customers: 160
  products: 329
  orders: 165
  order_items: 1709
  deposits: 85
  expenses: 0
  stock_alerts: 9