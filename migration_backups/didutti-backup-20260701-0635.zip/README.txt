Didutti Kids backup
Generated: 2026-07-01T03:35:00.902Z

Structure:
  manifest.json          - backup metadata
  versions.json          - list of all versions
  global/                - tables not scoped to a version (app_settings, staff_members)
  versions/<name>__<id>/ - one folder per version, containing:
      version.json
      products.json
      customers.json
      orders.json
      order_items.json
      deposits.json
      expenses.json
      stock_alerts.json

To restore: open Admin > Backup & Restore, upload either the full ZIP
or any single JSON file from inside it. Rows are upserted by id so
existing rows with the same id are overwritten.
